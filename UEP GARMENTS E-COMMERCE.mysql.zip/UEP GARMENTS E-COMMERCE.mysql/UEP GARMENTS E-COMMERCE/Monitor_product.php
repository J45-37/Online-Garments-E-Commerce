<?php
// Connect to the database (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "E-Commerce";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch ticket information from the database
$sql = "SELECT * FROM tickets";
$result = $conn->query($sql);

// Check if there are any tickets
if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Product Name : " . $row["Product-Selected"]. " - Seller Name: " . $row["seller_name"]. "<br>";
    }
} else {
    echo "Not Available";
}

// Close connection
$conn->close();
?>

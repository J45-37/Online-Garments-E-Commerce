document.addEventListener('DOMContentLoaded', function() {
    const checkoutform= document.getElementById('checkout-form');
    const productlist = document.getElementById('productlist');
    const productGeneratedSpan = document.getElementById('checked-out');
    const resetButton = document.querySelector('button[type="reset"]');

    ticketForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const sellerNameInput = document.getElementById('garments-admin');
        const numTicketsInput = document.getElementById('num-products');
        const sellerName = staffnameinput.value;
        const numTickets = productnameinput.value;

        const xhr = new XMLHttpRequest();
        xhr.open('GET', `generate_ticket.php?seller-name=${sellerName}&num-product=${numProduct}`, true);
        xhr.onload = function() {
            if (xhr.status === 200) {
                const response = xhr.responseText;
                const ProductList = response.split("<br>");
                for (let i = 0; i < productButton.length - 1; i++) { // Remove the last empty element
                    const newTicket = document.createElement('tr');
                    newTicket.innerHTML = `
                        <td>${productnameinput[i]}</td>
                        <td>${Sellername}</td>
                        <td>Available</td>
                    `;
                    ticketList.appendChild(newProduct);
                }
                ProductGeneratedSpan.textContent = `${ViewProduct} Product generated`;
            }
        };
        xhr.send();
    });

    resetButton.addEventListener('click', function() {
        ProductForm.reset(); // Reset the form
        ProductList.innerHTML = ''; // Clear the Product list
        ProductGeneratedSpan.textContent = '0 Checked Out'; // Reset the ticket count
    });
});